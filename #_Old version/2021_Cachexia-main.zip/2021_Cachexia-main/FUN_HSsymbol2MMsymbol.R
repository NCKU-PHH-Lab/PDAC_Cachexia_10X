##### Human gene symbol(HGNC) to Mouse gene symbol (MGI) #####
HSsymbol2MMsymbol<- function(df,HS_col){
  
  require(epanetReader)
  
  # download the dataset
  if(!file.exists("HOM_MouseHumanSequence.rpt")){
    download.file("http://www.informatics.jax.org/downloads/reports/HOM_MouseHumanSequence.rpt", destfile = "HOM_MouseHumanSequence.rpt")
  }
  MouseHumanSequence.df <- read.csv(file=paste0(getwd(),"/HOM_MouseHumanSequence.rpt"), sep = "\t")
  
  # create new column
  df <- data.frame(df, "MM-symbol"=rep(NA,nrow(df)))
  cat("Create new column: OK","\n")
  
  # crate alias set
  query <- df[[HS_col]]
  cat("Create alias query: OK","\n")
  
  # transformation
  cat("Start alias transformation","\n")
  count <- 1
  for (i in 1:length(query)) {
    
    HSID <- as.numeric(row.names(MouseHumanSequence.df[MouseHumanSequence.df$Symbol==query[i],] ))
    MMID <- c()
    if(length(HSID)>0){
      for (l in 1:length(HSID)) {
        n <- HSID[l]
        while(MouseHumanSequence.df$Common.Organism.Name[n]!="mouse, laboratory"){
          n <- n-1
        }
        MMID[l] <- n
      }
      mmsymbol <- MouseHumanSequence.df$Symbol[MMID]
    }else{
      mmsymbol <- c()
    }
    
    n_mmsymbol <- length(mmsymbol)
    
    cat(" HS",i,"\n")
    if(n_mmsymbol==1){
      df[count,ncol(df)] <- mmsymbol
      count <- count+1
      cat("  MM","1","\n")
    }else if(n_mmsymbol>1){
      working.df <- df[c(1:count-1),]
      
      ## Expend the row that having multiple symbol
      for(j in 1: n_mmsymbol){
        working.df <- rbind(working.df,df[count,])
      }
      working.df <- rbind(working.df,df[-c(1:count),])
      df <- working.df
      rm(working.df)
      
      ## Insert the gene symbol
      for (k in 1:n_mmsymbol) {
        df[count+k-1,ncol(df)] <- mmsymbol[k]
      }
      count <- count+k
      cat("  MM",k,"\n")
    }else{
      df[count,ncol(df)] <- 0
      count <- count+1
      cat("  MM not found","\n")
    }  
  }
  row.names(df) <- c(1:nrow(df))
  cat("Finish")
  return(df)
}